import java.util.Scanner;
/**
 * RSA加密算法样例类
 * @author Zhangsw
 *
 */
public class RSA
{
	/**
	 * 加密和解密过程函数
	 * @param a 明文或密文
	 * @param b e或d
	 * @param c n
	 * @return 返回加密后的数字
	 */
	private static int candp(int a,int b,int c)
	{
	    int r=1;
	    while(b>0)
	    {
	        r*=a;
	        r%=c;
	        b--;
	    }
	    return r;
	}
	
	
	//以下是主函数
	public static void main(String[] args)
	{
		int p,q,e,d,m,n,t,c,r;
	    Scanner sc=new Scanner(System.in);
	    System.out.print("please input the p,q:");
	    
	    //读取p和q
	    p=sc.nextInt();
	    q=sc.nextInt();
	    
	    //计算n
	    n=p*q;
	    System.out.println("the n is "+n);
	    
	    //计算t
	    t=(p-1)*(q-1);
	    System.out.println("the t is "+t);
	    System.out.print("please input the e:");
	    
	    //读取公钥e
	    e=sc.nextInt();
	    
	    //如果e不在合理范围内重新读取
	    while(e<1||e>t)
	    {
	    	System.out.print("e is error, please input again:");
	    	e=sc.nextInt();
	    }
	    d=1;
	    
	    //计算私钥d
	    while(((e*d)%t)!=1)
	    {
	        d++;
	    }
	    System.out.println("then calculate out that the d is "+d);
	    
	    //选择进行加密或解密
	    System.out.println("the cipher please input 1");
	    System.out.println("the plain please input 2");
	    System.out.print("exit please input 0:");
	    while(true)
	    {
	    	r=sc.nextInt();
	    	if(r==1)
	        {
	    		System.out.print("input the m:");
	            m=sc.nextInt();
	            c=candp(m,e,n);
	            System.out.println("the cipher is "+c);
	        }
	        else if(r==2)
	        {
	        	System.out.print("input the c:");
	            c=sc.nextInt();
	            m=candp(c,d,n);
	            System.out.println("the cipher is "+m);
	        }
	        else if(r==0)
	        {
	            break;
	        }
	    	System.out.println("the cipher please input 1");
	    	System.out.println("the plain please input 2");
	    	System.out.print("exit please input 0:");
	    }
	    sc.close();
	    System.out.println("The test is over!");
	}

}
