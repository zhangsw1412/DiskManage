#include <stdio.h>

/**
 * 加密和解密过程函数
 * @param a 明文或密文
 * @param b e或d
 * @param c n
 * @return 返回加密后的数字
 */
int candp(int a,int b,int c)
{
    int r=1;
    while(b)
    {
        r*=a;
        r%=c;
        b--;
    }
    return r;
}

//以下是主函数
int main()
{
    int p,q,e,d,m,n,t,c,r;
    char s;
    printf("please input the p,q:");

    //读取p和q
    scanf("%d%d",&p,&q);

    //计算n
    n=p*q;
    printf("the n is %3d\n",n);

    //计算t
    t=(p-1)*(q-1);
    printf("the t is %3d\n",t);
    printf("please input the e:");

    //读取公钥e
    scanf("%d",&e);

    //如果e不在合理范围内重新读取
    while(e<1||e>t)
    {
        printf("e; is error, please input again:");
        scanf("%d",&e);
    }
    d=1;

    //计算私钥d
    while(((e*d)%t)!=1)
    {
        d++;
    }
    printf("then calculate out that the d is %d\n",d);

    //选择进行加密或解密
    printf("the cipher please input 1\n");
    printf("the plain please input 2\n");
    printf("exit please input 0:");
    while(scanf("%d",&r))
    {
        if(r==1)
        {
            printf("input the m:");
            scanf("%d",&m);
            c=candp(m,e,n);
            printf("the cipher is %d\n\n",c);
        }
        else if(r==2)
        {
            printf("input the c:");
            scanf("%d",&c);
            m=candp(c,d,n);
            printf("the cipher is %d\n\n",m);
        }
        else if(r==0)
        {
            break;
        }
        printf("the cipher please input 1\n");
        printf("the plain please input 2\n");
        printf("exit please input 0:");
    }
    getch();
}
